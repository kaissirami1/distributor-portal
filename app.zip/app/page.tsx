export const metadata = {
  title: "Home",
};

export default function HomePage() {
  return (
    <main className="min-h-screen text-white bg-[radial-gradient(circle_at_top_left,#7a5a2a_0%,#2a2112_28%,#090806_65%,#000_100%)]">
      <section className="px-6 py-36 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(255,255,255,0.06),transparent)] pointer-events-none" />

        <div className="max-w-6xl mx-auto relative">
          <p className="fade-up text-sm uppercase tracking-[0.45em] text-amber-300/70 mb-6">
            Makram Distributions
          </p>

          <h1 className="fade-up text-6xl md:text-8xl font-bold leading-[0.95]">
            Distribution Built
            <br />
            <span className="text-amber-100/80">For Better Products</span>
          </h1>

          <p className="fade-up-delay text-stone-300 max-w-3xl mx-auto mt-8 text-lg md:text-xl">
            We review emerging and retail-ready products for distribution
            opportunities across California markets, helping strong brands move
            toward the right channels with a selective, organized process.
          </p>

          <div className="fade-up-delay mt-10 flex flex-col sm:flex-row justify-center gap-4">
            <a
              href="/submit"
              className="bg-amber-200 text-black px-8 py-4 rounded-full font-semibold hover:bg-amber-100 transition"
            >
              Submit Your Product
            </a>

            <a
              href="#process"
              className="border border-amber-200/30 px-8 py-4 rounded-full font-semibold hover:bg-amber-200/10 transition"
            >
              View Process
            </a>
          </div>
        </div>
      </section>

      <section className="px-6 py-20">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          {[
            [
              "Selective Review",
              "Every submission is reviewed for fit, readiness, and market potential.",
            ],
            [
              "California Focus",
              "Focused on Orange County, Los Angeles, San Diego, and surrounding markets.",
            ],
            [
              "Organized Onboarding",
              "Approved products can move into a structured next-step review process.",
            ],
          ].map(([title, text]) => (
            <div
              key={title}
              className="hover-lift bg-white/[0.06] border border-amber-200/10 rounded-3xl p-7 backdrop-blur-xl shadow-2xl"
            >
              <h3 className="text-xl font-semibold text-amber-100 mb-3">
                {title}
              </h3>
              <p className="text-stone-300">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="px-6 py-24 border-t border-amber-200/10">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-14 items-center">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-amber-300/70 mb-4">
              What We Do
            </p>

            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              We help identify products with distribution potential.
            </h2>

            <p className="text-stone-300 text-lg">
              Makram Distributions reviews products for potential retail,
              wholesale, and regional distribution opportunities. We focus on
              small products with strong presentation, clear value, and realistic
              market fit.
            </p>
          </div>

          <div className="hover-lift bg-black/35 border border-amber-200/10 rounded-3xl p-8">
            <h3 className="text-2xl font-bold text-amber-100 mb-5">
              What We Look For
            </h3>

            <ul className="space-y-4 text-stone-300">
              <li>• Small packaged consumer products</li>
              <li>• Strong branding and presentation</li>
              <li>• Clear retail or wholesale positioning</li>
              <li>• Products ready for distribution review</li>
              <li>• Emerging brands with growth potential</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="process" className="px-6 py-24 border-t border-amber-200/10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <p className="text-sm uppercase tracking-[0.35em] text-amber-300/70 mb-4">
              Process
            </p>
            <h2 className="text-4xl md:text-5xl font-bold">
              A clear review path
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              [
                "01",
                "Submit",
                "Provide your product details, documents, images, and barcode information.",
              ],
              [
                "02",
                "Review",
                "We review the submission for market fit, presentation, and readiness.",
              ],
              [
                "03",
                "Contact",
                "If there is a fit, we reach out for more information or next steps.",
              ],
              [
                "04",
                "Move Forward",
                "Approved products can move into onboarding and distribution planning.",
              ],
            ].map(([number, title, text]) => (
              <div
                key={number}
                className="hover-lift bg-white/[0.05] border border-amber-200/10 rounded-3xl p-6"
              >
                <p className="text-amber-300/60 mb-3">{number}</p>
                <h3 className="font-semibold text-amber-100 mb-3">{title}</h3>
                <p className="text-stone-300 text-sm">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-24">
        <div className="hover-lift max-w-6xl mx-auto bg-black/40 border border-amber-200/10 rounded-[2rem] p-10 md:p-14 text-center backdrop-blur-xl">
          <p className="text-sm uppercase tracking-[0.35em] text-amber-300/70 mb-4">
            Product Categories
          </p>

          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            Built for more than one category
          </h2>

          <div className="grid md:grid-cols-5 gap-4 text-stone-300">
            {[
              "Food & Beverage",
              "Specialty Retail",
              "Lifestyle",
              "Household",
              "Emerging Brands",
            ].map((item) => (
              <div
                key={item}
                className="hover-lift border border-amber-200/10 rounded-2xl p-4 bg-white/[0.04]"
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-24 border-t border-amber-200/10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-10">
            Frequently Asked Questions
          </h2>

          <div className="space-y-5">
            {[
              [
                "Do you guarantee placement?",
                "No. Every product is reviewed before any decision is made.",
              ],
              [
                "Do you work with small brands?",
                "Yes. We are especially interested in small and emerging products with strong potential.",
              ],
              [
                "What happens after submission?",
                "Your product is reviewed internally. If it appears to be a fit, we contact you for next steps.",
              ],
              [
                "What markets do you focus on?",
                "We focus on California, especially Orange County, Los Angeles, San Diego, and surrounding areas.",
              ],
            ].map(([q, a]) => (
              <div
                key={q}
                className="hover-lift bg-black/35 border border-amber-200/10 rounded-2xl p-6"
              >
                <h3 className="font-semibold text-amber-100 mb-2">{q}</h3>
                <p className="text-stone-300">{a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-28 text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-5">
          Ready to submit your product?
        </h2>

        <p className="text-stone-300 mb-9">
          Start the application and well review it for distribution potential.
        </p>

        <a
          href="/submit"
          className="bg-amber-200 text-black px-10 py-4 rounded-full font-semibold hover:bg-amber-100 transition"
        >
          Submit Your Product
        </a>
      </section>
    </main>
  );
}